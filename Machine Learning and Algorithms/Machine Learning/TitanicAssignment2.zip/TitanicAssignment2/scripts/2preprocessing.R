#Purpose: preprocess the data - handle missing data
#Author: Sean Hogan

library(dplyr)

#load data
titanic <- read.csv("data/train.csv", stringsAsFactors = TRUE)

#change blank strings to NA
titanic[titanic == ""                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ] <- NA

#drop unused columns
titanic <- titanic %>%
  select(-PassengerId, -Name, -Ticket, -Cabin)

#handle missing values
titanic$Age[is.na(titanic$Age)] <- median(titanic$Age, na.rm = TRUE)
titanic$Embarked[is.na(titanic$Embarked)] <- "S"

#change to factor
titanic <- titanic %>%
  mutate(Survived = factor(Survived),
         Pclass = factor(Pclass),
         Sex = factor(Sex),
         Embarked = factor(Embarked))

#save new dataset
write.csv(titanic, "data/new_clean_titanic_data.csv", row.names = FALSE)