#Purpose: eda - examine dataset
#Author: Sean Hogan

library(tidyverse)

#load data
titanic <- read.csv("data/train.csv", stringsAsFactors = TRUE)

#structure and summary
str(titanic)
summary(titanic)
#check for missing data
colSums(is.na(titanic))
sapply(titanic, function(col) sum(col == "", na.rm = TRUE))

#plots
ggplot(titanic, aes(x = Survived)) + geom_bar() + ggtitle("Survival Count")
ggplot(titanic, aes(x = Age)) + geom_histogram(bins = 30) + ggtitle("Age Distribution")
ggplot(titanic, aes(x = Pclass, fill = factor(Survived))) + 
  geom_bar(position = "fill") + ggtitle("Class vs Survival")