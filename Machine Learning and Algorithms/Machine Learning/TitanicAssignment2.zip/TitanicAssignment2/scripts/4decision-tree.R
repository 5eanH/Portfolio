#Purpose: train and test decision tree
#Author: Sean Hogan

library(rpart)
library(caret)
library(rpart.plot)

#load clean data
titanic <- read.csv("data/new_clean_titanic_data.csv", stringsAsFactors = TRUE)

#split data
set.seed(42)
train_index <- createDataPartition(titanic$Survived, p = 0.8, list = FALSE)
train <- titanic[train_index, ]
test <- titanic[-train_index, ]

#train the model
tree_model <- rpart(Survived ~ ., data = train, method = "class")
rpart.plot(tree_model)

#predict and evaluate
tree_preds <- predict(tree_model, test, type = "class")
tree_preds <- factor(tree_preds, levels = c(0, 1))
test_actual <- factor(test$Survived, levels = c(0, 1))
confMatrix <- confusionMatrix(tree_preds, test_actual)
print(confMatrix)

#save prediction
saveRDS(tree_preds, "output/tree_preds.rds")