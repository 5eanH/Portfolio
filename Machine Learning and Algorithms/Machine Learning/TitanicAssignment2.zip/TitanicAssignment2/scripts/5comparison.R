#Purpose: compare models
#Author: Sean Hogan

#load the predictions and actuals
nb_preds <- readRDS("output/nb_preds.rds")
tree_preds <- readRDS("output/tree_preds.rds")
actuals <- readRDS("output/actuals.rds")

#Calculate accuracy 
nb_acc <- mean(nb_preds == actuals)
tree_acc <- mean(tree_preds == actuals)

#show results
cat("Naive Bayes Accuracy:", round(nb_acc, 4), "\n")
cat("Decision Tree Accuracy:", round(tree_acc, 4), "\n")

if (nb_acc > tree_acc) {
  cat("Naive Bayes performed best.\n")
} else if (tree_acc > nb_acc) {
  cat("Decision Tree performed best.\n")
} else {
  cat("Both performed equally.\n")
}