#Function: train and test naive bayes
#Author: Sean Hogan

library(e1071)
library(caret)

#load clean data
titanic <- read.csv("data/new_clean_titanic_data.csv", stringsAsFactors = TRUE)

#split data
set.seed(42)
train_index <- createDataPartition(titanic$Survived, p = 0.8, list = FALSE)
train <- titanic[train_index, ]
test <- titanic[-train_index, ]

#train model
nb_model <- naiveBayes(Survived ~ ., data = train)
nb_preds <- predict(nb_model, test)

#check factor levels match
nb_preds <- factor(nb_preds, levels = c(0, 1))
test_actual <- factor(test$Survived, levels = c(0, 1))

#eval
confMatrix <- confusionMatrix(nb_preds, test_actual)
print(confMatrix)

#save prediction
saveRDS(nb_preds, "output/nb_preds.rds")
saveRDS(test$Survived, "output/actuals.rds")